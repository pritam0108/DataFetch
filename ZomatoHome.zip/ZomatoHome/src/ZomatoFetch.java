import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class ZomatoFetch {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Document doc;
		try{
		//Document doc= Jsoup.connect("https://www.zomato.com/ncr/restaurants").timeout(10*1000).ignoreHttpErrors(true).userAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.152 Safari/537.36").get();
		Connection con= Jsoup.connect("http://www.hungrygowhere.com/search-results/Golden+Jade+Restaurant+-+Main/?search_type=show_exact_match&search_biz_id=f5bd0200&general=1");
		con.userAgent("Mozilla/5.0 Chrome/33.0.1750.152 Safari/537.36");
		con.timeout(6000);
		con.ignoreHttpErrors(true);
		con.followRedirects(true);
		//Response res= con.execute();
		doc = con.get(); 
		
		Elements e= doc.select("div#page_result");
		for(Element element : e.select("div.entry")){
			//String title =element.select("div.result-title a").text();
			//System.out.println(title);
			String cuisine = element.select("div.title-wrap a").text();
			System.out.println(cuisine);
			String loc = element.select("span.location a").text();
			System.out.println(loc);
			
		}
		}catch(IOException e){
			e.printStackTrace();
		}
		
	}

}
